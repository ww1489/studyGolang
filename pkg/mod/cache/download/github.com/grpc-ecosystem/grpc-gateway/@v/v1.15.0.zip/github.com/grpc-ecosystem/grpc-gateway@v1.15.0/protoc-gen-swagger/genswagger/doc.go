// Package genswagger provides a code generator for swagger.
package genswagger
