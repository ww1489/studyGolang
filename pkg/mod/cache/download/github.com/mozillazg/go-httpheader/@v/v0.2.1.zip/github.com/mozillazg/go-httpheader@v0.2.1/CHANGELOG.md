# Changelog

## 0.2.1 (2018-11-03)

* add go.mod file to identify as a module


## 0.2.0 (2017-06-24)

* support http.Header field.


## 0.1.0 (2017-06-10)

* Initial Release
