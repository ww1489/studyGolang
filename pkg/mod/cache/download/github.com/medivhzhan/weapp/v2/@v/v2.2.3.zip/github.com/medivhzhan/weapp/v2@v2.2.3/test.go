package weapp

type (
	object = map[string]interface{}
)

const (
	testIMGName = "title.png"
)
